# DAY 1 - Part 3

A Pen created on CodePen.io. Original URL: [https://codepen.io/freemote/pen/ExvevYp/45f2b65556afba27181a27acbea58a28](https://codepen.io/freemote/pen/ExvevYp/45f2b65556afba27181a27acbea58a28).

